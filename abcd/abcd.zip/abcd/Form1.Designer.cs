﻿namespace abcd
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Disconnect1 = new System.Windows.Forms.Button();
            this.tb8OFF = new System.Windows.Forms.Button();
            this.tb8ON = new System.Windows.Forms.Button();
            this.tb7OFF = new System.Windows.Forms.Button();
            this.tb7ON = new System.Windows.Forms.Button();
            this.tb6OFF = new System.Windows.Forms.Button();
            this.tb6ON = new System.Windows.Forms.Button();
            this.tb5OFF = new System.Windows.Forms.Button();
            this.tb5ON = new System.Windows.Forms.Button();
            this.tb4OFF = new System.Windows.Forms.Button();
            this.tb4ON = new System.Windows.Forms.Button();
            this.tb3OFF = new System.Windows.Forms.Button();
            this.tb3ON = new System.Windows.Forms.Button();
            this.tb2OFF = new System.Windows.Forms.Button();
            this.tb2ON = new System.Windows.Forms.Button();
            this.tb1OFF = new System.Windows.Forms.Button();
            this.tb1ON = new System.Windows.Forms.Button();
            this.Send = new System.Windows.Forms.Button();
            this.IP1 = new System.Windows.Forms.TextBox();
            this.IP2 = new System.Windows.Forms.TextBox();
            this.IP3 = new System.Windows.Forms.TextBox();
            this.IP4 = new System.Windows.Forms.TextBox();
            this.Save = new System.Windows.Forms.Button();
            this.IPsetup = new System.Windows.Forms.GroupBox();
            this.IPsetup2 = new System.Windows.Forms.GroupBox();
            this.Save2 = new System.Windows.Forms.Button();
            this.IP42 = new System.Windows.Forms.TextBox();
            this.IP32 = new System.Windows.Forms.TextBox();
            this.IP22 = new System.Windows.Forms.TextBox();
            this.IP12 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Disconnect2 = new System.Windows.Forms.Button();
            this.tb8OFF2 = new System.Windows.Forms.Button();
            this.tb8ON2 = new System.Windows.Forms.Button();
            this.tb7OFF2 = new System.Windows.Forms.Button();
            this.tb7ON2 = new System.Windows.Forms.Button();
            this.tb6OFF2 = new System.Windows.Forms.Button();
            this.tb6ON2 = new System.Windows.Forms.Button();
            this.tb5OFF2 = new System.Windows.Forms.Button();
            this.tb5ON2 = new System.Windows.Forms.Button();
            this.tb4OFF2 = new System.Windows.Forms.Button();
            this.tb4ON2 = new System.Windows.Forms.Button();
            this.tb3OFF2 = new System.Windows.Forms.Button();
            this.tb3ON2 = new System.Windows.Forms.Button();
            this.tb2OFF2 = new System.Windows.Forms.Button();
            this.tb2ON2 = new System.Windows.Forms.Button();
            this.tb1OFF2 = new System.Windows.Forms.Button();
            this.tb1ON2 = new System.Windows.Forms.Button();
            this.Send2 = new System.Windows.Forms.Button();
            this.Text2 = new System.Windows.Forms.Label();
            this.Text1 = new System.Windows.Forms.Label();
            this.lstRegvalues = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            this.IPsetup.SuspendLayout();
            this.IPsetup2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Disconnect1);
            this.groupBox1.Controls.Add(this.tb8OFF);
            this.groupBox1.Controls.Add(this.tb8ON);
            this.groupBox1.Controls.Add(this.tb7OFF);
            this.groupBox1.Controls.Add(this.tb7ON);
            this.groupBox1.Controls.Add(this.tb6OFF);
            this.groupBox1.Controls.Add(this.tb6ON);
            this.groupBox1.Controls.Add(this.tb5OFF);
            this.groupBox1.Controls.Add(this.tb5ON);
            this.groupBox1.Controls.Add(this.tb4OFF);
            this.groupBox1.Controls.Add(this.tb4ON);
            this.groupBox1.Controls.Add(this.tb3OFF);
            this.groupBox1.Controls.Add(this.tb3ON);
            this.groupBox1.Controls.Add(this.tb2OFF);
            this.groupBox1.Controls.Add(this.tb2ON);
            this.groupBox1.Controls.Add(this.tb1OFF);
            this.groupBox1.Controls.Add(this.tb1ON);
            this.groupBox1.Controls.Add(this.Send);
            this.groupBox1.Enabled = false;
            this.groupBox1.Location = new System.Drawing.Point(52, 93);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(335, 432);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Line 1";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter_1);
            // 
            // Disconnect1
            // 
            this.Disconnect1.BackColor = System.Drawing.Color.Red;
            this.Disconnect1.Location = new System.Drawing.Point(83, 382);
            this.Disconnect1.Name = "Disconnect1";
            this.Disconnect1.Size = new System.Drawing.Size(154, 34);
            this.Disconnect1.TabIndex = 28;
            this.Disconnect1.Text = "Disconnect";
            this.Disconnect1.UseVisualStyleBackColor = false;
            this.Disconnect1.Click += new System.EventHandler(this.Disconnect1_Click);
            // 
            // tb8OFF
            // 
            this.tb8OFF.BackColor = System.Drawing.Color.Lime;
            this.tb8OFF.Location = new System.Drawing.Point(175, 190);
            this.tb8OFF.Name = "tb8OFF";
            this.tb8OFF.Size = new System.Drawing.Size(97, 35);
            this.tb8OFF.TabIndex = 27;
            this.tb8OFF.Text = "Thiết bị 8";
            this.tb8OFF.UseVisualStyleBackColor = false;
            this.tb8OFF.Click += new System.EventHandler(this.tb8OFF_Click);
            // 
            // tb8ON
            // 
            this.tb8ON.BackColor = System.Drawing.Color.White;
            this.tb8ON.Location = new System.Drawing.Point(175, 190);
            this.tb8ON.Name = "tb8ON";
            this.tb8ON.Size = new System.Drawing.Size(97, 35);
            this.tb8ON.TabIndex = 26;
            this.tb8ON.Text = "Thiết bị 8";
            this.tb8ON.UseVisualStyleBackColor = false;
            this.tb8ON.Click += new System.EventHandler(this.tb8ON_Click);
            // 
            // tb7OFF
            // 
            this.tb7OFF.BackColor = System.Drawing.Color.Lime;
            this.tb7OFF.Location = new System.Drawing.Point(175, 138);
            this.tb7OFF.Name = "tb7OFF";
            this.tb7OFF.Size = new System.Drawing.Size(97, 35);
            this.tb7OFF.TabIndex = 25;
            this.tb7OFF.Text = "Thiết bị 7";
            this.tb7OFF.UseVisualStyleBackColor = false;
            this.tb7OFF.Click += new System.EventHandler(this.tb7OFF_Click);
            // 
            // tb7ON
            // 
            this.tb7ON.BackColor = System.Drawing.Color.White;
            this.tb7ON.Location = new System.Drawing.Point(175, 138);
            this.tb7ON.Name = "tb7ON";
            this.tb7ON.Size = new System.Drawing.Size(97, 35);
            this.tb7ON.TabIndex = 24;
            this.tb7ON.Text = "Thiết bị 7";
            this.tb7ON.UseVisualStyleBackColor = false;
            this.tb7ON.Click += new System.EventHandler(this.tb7ON_Click);
            // 
            // tb6OFF
            // 
            this.tb6OFF.BackColor = System.Drawing.Color.Lime;
            this.tb6OFF.Location = new System.Drawing.Point(175, 84);
            this.tb6OFF.Name = "tb6OFF";
            this.tb6OFF.Size = new System.Drawing.Size(97, 35);
            this.tb6OFF.TabIndex = 23;
            this.tb6OFF.Text = "Thiết bị 6";
            this.tb6OFF.UseVisualStyleBackColor = false;
            this.tb6OFF.Click += new System.EventHandler(this.tb6OFF_Click);
            // 
            // tb6ON
            // 
            this.tb6ON.BackColor = System.Drawing.Color.White;
            this.tb6ON.Location = new System.Drawing.Point(175, 84);
            this.tb6ON.Name = "tb6ON";
            this.tb6ON.Size = new System.Drawing.Size(97, 35);
            this.tb6ON.TabIndex = 22;
            this.tb6ON.Text = "Thiết bị 6";
            this.tb6ON.UseVisualStyleBackColor = false;
            this.tb6ON.Click += new System.EventHandler(this.tb6ON_Click);
            // 
            // tb5OFF
            // 
            this.tb5OFF.BackColor = System.Drawing.Color.Lime;
            this.tb5OFF.Location = new System.Drawing.Point(175, 33);
            this.tb5OFF.Name = "tb5OFF";
            this.tb5OFF.Size = new System.Drawing.Size(97, 35);
            this.tb5OFF.TabIndex = 21;
            this.tb5OFF.Text = "Thiết bị 5";
            this.tb5OFF.UseVisualStyleBackColor = false;
            this.tb5OFF.Click += new System.EventHandler(this.tb5OFF_Click);
            // 
            // tb5ON
            // 
            this.tb5ON.BackColor = System.Drawing.Color.White;
            this.tb5ON.Location = new System.Drawing.Point(175, 33);
            this.tb5ON.Name = "tb5ON";
            this.tb5ON.Size = new System.Drawing.Size(97, 35);
            this.tb5ON.TabIndex = 20;
            this.tb5ON.Text = "Thiết bị 5";
            this.tb5ON.UseVisualStyleBackColor = false;
            this.tb5ON.Click += new System.EventHandler(this.tb5ON_Click);
            // 
            // tb4OFF
            // 
            this.tb4OFF.BackColor = System.Drawing.Color.Lime;
            this.tb4OFF.Location = new System.Drawing.Point(52, 190);
            this.tb4OFF.Name = "tb4OFF";
            this.tb4OFF.Size = new System.Drawing.Size(97, 35);
            this.tb4OFF.TabIndex = 19;
            this.tb4OFF.Text = "Thiết bị 4";
            this.tb4OFF.UseVisualStyleBackColor = false;
            this.tb4OFF.Click += new System.EventHandler(this.tb4OFF_Click);
            // 
            // tb4ON
            // 
            this.tb4ON.BackColor = System.Drawing.Color.White;
            this.tb4ON.Location = new System.Drawing.Point(52, 190);
            this.tb4ON.Name = "tb4ON";
            this.tb4ON.Size = new System.Drawing.Size(97, 35);
            this.tb4ON.TabIndex = 18;
            this.tb4ON.Text = "Thiết bị 4";
            this.tb4ON.UseVisualStyleBackColor = false;
            this.tb4ON.Click += new System.EventHandler(this.tb4ON_Click);
            // 
            // tb3OFF
            // 
            this.tb3OFF.BackColor = System.Drawing.Color.Lime;
            this.tb3OFF.Location = new System.Drawing.Point(52, 138);
            this.tb3OFF.Name = "tb3OFF";
            this.tb3OFF.Size = new System.Drawing.Size(97, 35);
            this.tb3OFF.TabIndex = 17;
            this.tb3OFF.Text = "Thiết bị 3";
            this.tb3OFF.UseVisualStyleBackColor = false;
            this.tb3OFF.Click += new System.EventHandler(this.tb3OFF_Click);
            // 
            // tb3ON
            // 
            this.tb3ON.BackColor = System.Drawing.Color.White;
            this.tb3ON.Location = new System.Drawing.Point(52, 138);
            this.tb3ON.Name = "tb3ON";
            this.tb3ON.Size = new System.Drawing.Size(97, 35);
            this.tb3ON.TabIndex = 16;
            this.tb3ON.Text = "Thiết bị 3";
            this.tb3ON.UseVisualStyleBackColor = false;
            this.tb3ON.Click += new System.EventHandler(this.tb3ON_Click);
            // 
            // tb2OFF
            // 
            this.tb2OFF.BackColor = System.Drawing.Color.Lime;
            this.tb2OFF.Location = new System.Drawing.Point(52, 84);
            this.tb2OFF.Name = "tb2OFF";
            this.tb2OFF.Size = new System.Drawing.Size(97, 35);
            this.tb2OFF.TabIndex = 15;
            this.tb2OFF.Text = "Thiết bị 2";
            this.tb2OFF.UseVisualStyleBackColor = false;
            this.tb2OFF.Click += new System.EventHandler(this.tb2OFF_Click);
            // 
            // tb2ON
            // 
            this.tb2ON.BackColor = System.Drawing.Color.White;
            this.tb2ON.Location = new System.Drawing.Point(52, 84);
            this.tb2ON.Name = "tb2ON";
            this.tb2ON.Size = new System.Drawing.Size(97, 35);
            this.tb2ON.TabIndex = 14;
            this.tb2ON.Text = "Thiết bị 2";
            this.tb2ON.UseVisualStyleBackColor = false;
            this.tb2ON.Click += new System.EventHandler(this.tb2ON_Click);
            // 
            // tb1OFF
            // 
            this.tb1OFF.BackColor = System.Drawing.Color.Lime;
            this.tb1OFF.Location = new System.Drawing.Point(52, 33);
            this.tb1OFF.Name = "tb1OFF";
            this.tb1OFF.Size = new System.Drawing.Size(97, 35);
            this.tb1OFF.TabIndex = 13;
            this.tb1OFF.Text = "Thiết bị 1";
            this.tb1OFF.UseVisualStyleBackColor = false;
            this.tb1OFF.Click += new System.EventHandler(this.tb1OFF_Click);
            // 
            // tb1ON
            // 
            this.tb1ON.BackColor = System.Drawing.Color.White;
            this.tb1ON.Location = new System.Drawing.Point(52, 33);
            this.tb1ON.Name = "tb1ON";
            this.tb1ON.Size = new System.Drawing.Size(97, 35);
            this.tb1ON.TabIndex = 12;
            this.tb1ON.Text = "Thiết bị 1";
            this.tb1ON.UseVisualStyleBackColor = false;
            this.tb1ON.Click += new System.EventHandler(this.tb1ON_Click);
            // 
            // Send
            // 
            this.Send.Location = new System.Drawing.Point(115, 267);
            this.Send.Name = "Send";
            this.Send.Size = new System.Drawing.Size(103, 32);
            this.Send.TabIndex = 11;
            this.Send.Text = "Gửi";
            this.Send.UseVisualStyleBackColor = true;
            this.Send.Click += new System.EventHandler(this.Send_Click);
            // 
            // IP1
            // 
            this.IP1.Location = new System.Drawing.Point(15, 23);
            this.IP1.Name = "IP1";
            this.IP1.Size = new System.Drawing.Size(29, 20);
            this.IP1.TabIndex = 5;
            this.IP1.Text = "192";
            this.IP1.TextChanged += new System.EventHandler(this.IP1_TextChanged);
            // 
            // IP2
            // 
            this.IP2.Location = new System.Drawing.Point(50, 23);
            this.IP2.Name = "IP2";
            this.IP2.Size = new System.Drawing.Size(28, 20);
            this.IP2.TabIndex = 6;
            this.IP2.Text = "168";
            // 
            // IP3
            // 
            this.IP3.Location = new System.Drawing.Point(84, 23);
            this.IP3.Name = "IP3";
            this.IP3.Size = new System.Drawing.Size(28, 20);
            this.IP3.TabIndex = 7;
            this.IP3.Text = "1";
            // 
            // IP4
            // 
            this.IP4.Location = new System.Drawing.Point(118, 23);
            this.IP4.Name = "IP4";
            this.IP4.Size = new System.Drawing.Size(28, 20);
            this.IP4.TabIndex = 8;
            this.IP4.Text = "51";
            // 
            // Save
            // 
            this.Save.Location = new System.Drawing.Point(249, 19);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(61, 26);
            this.Save.TabIndex = 9;
            this.Save.Text = "Connect";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // IPsetup
            // 
            this.IPsetup.Controls.Add(this.Save);
            this.IPsetup.Controls.Add(this.IP4);
            this.IPsetup.Controls.Add(this.IP3);
            this.IPsetup.Controls.Add(this.IP2);
            this.IPsetup.Controls.Add(this.IP1);
            this.IPsetup.Location = new System.Drawing.Point(52, 27);
            this.IPsetup.Name = "IPsetup";
            this.IPsetup.Size = new System.Drawing.Size(335, 60);
            this.IPsetup.TabIndex = 10;
            this.IPsetup.TabStop = false;
            // 
            // IPsetup2
            // 
            this.IPsetup2.Controls.Add(this.Save2);
            this.IPsetup2.Controls.Add(this.IP42);
            this.IPsetup2.Controls.Add(this.IP32);
            this.IPsetup2.Controls.Add(this.IP22);
            this.IPsetup2.Controls.Add(this.IP12);
            this.IPsetup2.Location = new System.Drawing.Point(411, 27);
            this.IPsetup2.Name = "IPsetup2";
            this.IPsetup2.Size = new System.Drawing.Size(335, 60);
            this.IPsetup2.TabIndex = 11;
            this.IPsetup2.TabStop = false;
            this.IPsetup2.Enter += new System.EventHandler(this.IPsetup2_Enter);
            // 
            // Save2
            // 
            this.Save2.Location = new System.Drawing.Point(256, 19);
            this.Save2.Name = "Save2";
            this.Save2.Size = new System.Drawing.Size(61, 26);
            this.Save2.TabIndex = 9;
            this.Save2.Text = "Connect";
            this.Save2.UseVisualStyleBackColor = true;
            this.Save2.Click += new System.EventHandler(this.Save2_Click);
            // 
            // IP42
            // 
            this.IP42.Location = new System.Drawing.Point(118, 23);
            this.IP42.Name = "IP42";
            this.IP42.Size = new System.Drawing.Size(28, 20);
            this.IP42.TabIndex = 8;
            this.IP42.Text = "52";
            // 
            // IP32
            // 
            this.IP32.Location = new System.Drawing.Point(84, 23);
            this.IP32.Name = "IP32";
            this.IP32.Size = new System.Drawing.Size(28, 20);
            this.IP32.TabIndex = 7;
            this.IP32.Text = "1";
            // 
            // IP22
            // 
            this.IP22.Location = new System.Drawing.Point(50, 23);
            this.IP22.Name = "IP22";
            this.IP22.Size = new System.Drawing.Size(28, 20);
            this.IP22.TabIndex = 6;
            this.IP22.Text = "168";
            // 
            // IP12
            // 
            this.IP12.Location = new System.Drawing.Point(15, 23);
            this.IP12.Name = "IP12";
            this.IP12.Size = new System.Drawing.Size(29, 20);
            this.IP12.TabIndex = 5;
            this.IP12.Text = "192";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Disconnect2);
            this.groupBox2.Controls.Add(this.tb8OFF2);
            this.groupBox2.Controls.Add(this.tb8ON2);
            this.groupBox2.Controls.Add(this.tb7OFF2);
            this.groupBox2.Controls.Add(this.tb7ON2);
            this.groupBox2.Controls.Add(this.tb6OFF2);
            this.groupBox2.Controls.Add(this.tb6ON2);
            this.groupBox2.Controls.Add(this.tb5OFF2);
            this.groupBox2.Controls.Add(this.tb5ON2);
            this.groupBox2.Controls.Add(this.tb4OFF2);
            this.groupBox2.Controls.Add(this.tb4ON2);
            this.groupBox2.Controls.Add(this.tb3OFF2);
            this.groupBox2.Controls.Add(this.tb3ON2);
            this.groupBox2.Controls.Add(this.tb2OFF2);
            this.groupBox2.Controls.Add(this.tb2ON2);
            this.groupBox2.Controls.Add(this.tb1OFF2);
            this.groupBox2.Controls.Add(this.tb1ON2);
            this.groupBox2.Controls.Add(this.Send2);
            this.groupBox2.Enabled = false;
            this.groupBox2.Location = new System.Drawing.Point(411, 93);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(335, 432);
            this.groupBox2.TabIndex = 28;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Line 2";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // Disconnect2
            // 
            this.Disconnect2.BackColor = System.Drawing.Color.Red;
            this.Disconnect2.Location = new System.Drawing.Point(94, 382);
            this.Disconnect2.Name = "Disconnect2";
            this.Disconnect2.Size = new System.Drawing.Size(154, 34);
            this.Disconnect2.TabIndex = 29;
            this.Disconnect2.Text = "Disconnect";
            this.Disconnect2.UseVisualStyleBackColor = false;
            this.Disconnect2.Click += new System.EventHandler(this.Disconnect2_Click);
            // 
            // tb8OFF2
            // 
            this.tb8OFF2.BackColor = System.Drawing.Color.Lime;
            this.tb8OFF2.Location = new System.Drawing.Point(175, 190);
            this.tb8OFF2.Name = "tb8OFF2";
            this.tb8OFF2.Size = new System.Drawing.Size(97, 35);
            this.tb8OFF2.TabIndex = 27;
            this.tb8OFF2.Text = "Thiết bị 8";
            this.tb8OFF2.UseVisualStyleBackColor = false;
            this.tb8OFF2.Click += new System.EventHandler(this.tb8OFF2_Click);
            // 
            // tb8ON2
            // 
            this.tb8ON2.BackColor = System.Drawing.Color.White;
            this.tb8ON2.Location = new System.Drawing.Point(175, 190);
            this.tb8ON2.Name = "tb8ON2";
            this.tb8ON2.Size = new System.Drawing.Size(97, 35);
            this.tb8ON2.TabIndex = 26;
            this.tb8ON2.Text = "Thiết bị 8";
            this.tb8ON2.UseVisualStyleBackColor = false;
            this.tb8ON2.Click += new System.EventHandler(this.tb8ON2_Click);
            // 
            // tb7OFF2
            // 
            this.tb7OFF2.BackColor = System.Drawing.Color.Lime;
            this.tb7OFF2.Location = new System.Drawing.Point(175, 138);
            this.tb7OFF2.Name = "tb7OFF2";
            this.tb7OFF2.Size = new System.Drawing.Size(97, 35);
            this.tb7OFF2.TabIndex = 25;
            this.tb7OFF2.Text = "Thiết bị 7";
            this.tb7OFF2.UseVisualStyleBackColor = false;
            this.tb7OFF2.Click += new System.EventHandler(this.tb7OFF2_Click);
            // 
            // tb7ON2
            // 
            this.tb7ON2.BackColor = System.Drawing.Color.White;
            this.tb7ON2.Location = new System.Drawing.Point(175, 138);
            this.tb7ON2.Name = "tb7ON2";
            this.tb7ON2.Size = new System.Drawing.Size(97, 35);
            this.tb7ON2.TabIndex = 24;
            this.tb7ON2.Text = "Thiết bị 7";
            this.tb7ON2.UseVisualStyleBackColor = false;
            this.tb7ON2.Click += new System.EventHandler(this.tb7ON2_Click);
            // 
            // tb6OFF2
            // 
            this.tb6OFF2.BackColor = System.Drawing.Color.Lime;
            this.tb6OFF2.Location = new System.Drawing.Point(175, 84);
            this.tb6OFF2.Name = "tb6OFF2";
            this.tb6OFF2.Size = new System.Drawing.Size(97, 35);
            this.tb6OFF2.TabIndex = 23;
            this.tb6OFF2.Text = "Thiết bị 6";
            this.tb6OFF2.UseVisualStyleBackColor = false;
            this.tb6OFF2.Click += new System.EventHandler(this.tb6OFF2_Click);
            // 
            // tb6ON2
            // 
            this.tb6ON2.BackColor = System.Drawing.Color.White;
            this.tb6ON2.Location = new System.Drawing.Point(175, 84);
            this.tb6ON2.Name = "tb6ON2";
            this.tb6ON2.Size = new System.Drawing.Size(97, 35);
            this.tb6ON2.TabIndex = 22;
            this.tb6ON2.Text = "Thiết bị 6";
            this.tb6ON2.UseVisualStyleBackColor = false;
            this.tb6ON2.Click += new System.EventHandler(this.tb6ON2_Click);
            // 
            // tb5OFF2
            // 
            this.tb5OFF2.BackColor = System.Drawing.Color.Lime;
            this.tb5OFF2.Location = new System.Drawing.Point(175, 33);
            this.tb5OFF2.Name = "tb5OFF2";
            this.tb5OFF2.Size = new System.Drawing.Size(97, 35);
            this.tb5OFF2.TabIndex = 21;
            this.tb5OFF2.Text = "Thiết bị 5";
            this.tb5OFF2.UseVisualStyleBackColor = false;
            this.tb5OFF2.Click += new System.EventHandler(this.tb5OFF2_Click);
            // 
            // tb5ON2
            // 
            this.tb5ON2.BackColor = System.Drawing.Color.White;
            this.tb5ON2.Location = new System.Drawing.Point(175, 33);
            this.tb5ON2.Name = "tb5ON2";
            this.tb5ON2.Size = new System.Drawing.Size(97, 35);
            this.tb5ON2.TabIndex = 20;
            this.tb5ON2.Text = "Thiết bị 5";
            this.tb5ON2.UseVisualStyleBackColor = false;
            this.tb5ON2.Click += new System.EventHandler(this.tb5ON2_Click);
            // 
            // tb4OFF2
            // 
            this.tb4OFF2.BackColor = System.Drawing.Color.Lime;
            this.tb4OFF2.Location = new System.Drawing.Point(52, 190);
            this.tb4OFF2.Name = "tb4OFF2";
            this.tb4OFF2.Size = new System.Drawing.Size(97, 35);
            this.tb4OFF2.TabIndex = 19;
            this.tb4OFF2.Text = "Thiết bị 4";
            this.tb4OFF2.UseVisualStyleBackColor = false;
            this.tb4OFF2.Click += new System.EventHandler(this.tb4OFF2_Click);
            // 
            // tb4ON2
            // 
            this.tb4ON2.BackColor = System.Drawing.Color.White;
            this.tb4ON2.Location = new System.Drawing.Point(52, 190);
            this.tb4ON2.Name = "tb4ON2";
            this.tb4ON2.Size = new System.Drawing.Size(97, 35);
            this.tb4ON2.TabIndex = 18;
            this.tb4ON2.Text = "Thiết bị 4";
            this.tb4ON2.UseVisualStyleBackColor = false;
            this.tb4ON2.Click += new System.EventHandler(this.tb4ON2_Click);
            // 
            // tb3OFF2
            // 
            this.tb3OFF2.BackColor = System.Drawing.Color.Lime;
            this.tb3OFF2.Location = new System.Drawing.Point(52, 138);
            this.tb3OFF2.Name = "tb3OFF2";
            this.tb3OFF2.Size = new System.Drawing.Size(97, 35);
            this.tb3OFF2.TabIndex = 17;
            this.tb3OFF2.Text = "Thiết bị 3";
            this.tb3OFF2.UseVisualStyleBackColor = false;
            this.tb3OFF2.Click += new System.EventHandler(this.tb3OFF2_Click);
            // 
            // tb3ON2
            // 
            this.tb3ON2.BackColor = System.Drawing.Color.White;
            this.tb3ON2.Location = new System.Drawing.Point(52, 138);
            this.tb3ON2.Name = "tb3ON2";
            this.tb3ON2.Size = new System.Drawing.Size(97, 35);
            this.tb3ON2.TabIndex = 16;
            this.tb3ON2.Text = "Thiết bị 3";
            this.tb3ON2.UseVisualStyleBackColor = false;
            this.tb3ON2.Click += new System.EventHandler(this.tb3ON2_Click);
            // 
            // tb2OFF2
            // 
            this.tb2OFF2.BackColor = System.Drawing.Color.Lime;
            this.tb2OFF2.Location = new System.Drawing.Point(52, 84);
            this.tb2OFF2.Name = "tb2OFF2";
            this.tb2OFF2.Size = new System.Drawing.Size(97, 35);
            this.tb2OFF2.TabIndex = 15;
            this.tb2OFF2.Text = "Thiết bị 2";
            this.tb2OFF2.UseVisualStyleBackColor = false;
            this.tb2OFF2.Click += new System.EventHandler(this.tb2OFF2_Click);
            // 
            // tb2ON2
            // 
            this.tb2ON2.BackColor = System.Drawing.Color.White;
            this.tb2ON2.Location = new System.Drawing.Point(52, 84);
            this.tb2ON2.Name = "tb2ON2";
            this.tb2ON2.Size = new System.Drawing.Size(97, 35);
            this.tb2ON2.TabIndex = 14;
            this.tb2ON2.Text = "Thiết bị 2";
            this.tb2ON2.UseVisualStyleBackColor = false;
            this.tb2ON2.Click += new System.EventHandler(this.tb2ON2_Click);
            // 
            // tb1OFF2
            // 
            this.tb1OFF2.BackColor = System.Drawing.Color.Lime;
            this.tb1OFF2.Location = new System.Drawing.Point(52, 33);
            this.tb1OFF2.Name = "tb1OFF2";
            this.tb1OFF2.Size = new System.Drawing.Size(97, 35);
            this.tb1OFF2.TabIndex = 13;
            this.tb1OFF2.Text = "Thiết bị 1";
            this.tb1OFF2.UseVisualStyleBackColor = false;
            this.tb1OFF2.Click += new System.EventHandler(this.tb1OFF2_Click);
            // 
            // tb1ON2
            // 
            this.tb1ON2.BackColor = System.Drawing.Color.White;
            this.tb1ON2.Location = new System.Drawing.Point(52, 33);
            this.tb1ON2.Name = "tb1ON2";
            this.tb1ON2.Size = new System.Drawing.Size(97, 35);
            this.tb1ON2.TabIndex = 12;
            this.tb1ON2.Text = "Thiết bị 1";
            this.tb1ON2.UseVisualStyleBackColor = false;
            this.tb1ON2.Click += new System.EventHandler(this.tb1ON2_Click);
            // 
            // Send2
            // 
            this.Send2.Location = new System.Drawing.Point(115, 267);
            this.Send2.Name = "Send2";
            this.Send2.Size = new System.Drawing.Size(103, 32);
            this.Send2.TabIndex = 11;
            this.Send2.Text = "Gửi";
            this.Send2.UseVisualStyleBackColor = true;
            this.Send2.Click += new System.EventHandler(this.Send2_Click);
            // 
            // Text2
            // 
            this.Text2.AutoSize = true;
            this.Text2.BackColor = System.Drawing.Color.Silver;
            this.Text2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Text2.Location = new System.Drawing.Point(407, 539);
            this.Text2.Name = "Text2";
            this.Text2.Size = new System.Drawing.Size(60, 22);
            this.Text2.TabIndex = 29;
            this.Text2.Text = "          ";
            // 
            // Text1
            // 
            this.Text1.AutoSize = true;
            this.Text1.BackColor = System.Drawing.Color.Silver;
            this.Text1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Text1.Location = new System.Drawing.Point(48, 539);
            this.Text1.Name = "Text1";
            this.Text1.Size = new System.Drawing.Size(60, 22);
            this.Text1.TabIndex = 30;
            this.Text1.Text = "          ";
            this.Text1.Click += new System.EventHandler(this.Text1_Click);
            // 
            // lstRegvalues
            // 
            this.lstRegvalues.FormattingEnabled = true;
            this.lstRegvalues.Location = new System.Drawing.Point(769, 102);
            this.lstRegvalues.Name = "lstRegvalues";
            this.lstRegvalues.Size = new System.Drawing.Size(111, 303);
            this.lstRegvalues.TabIndex = 33;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(897, 570);
            this.Controls.Add(this.lstRegvalues);
            this.Controls.Add(this.Text1);
            this.Controls.Add(this.Text2);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.IPsetup2);
            this.Controls.Add(this.IPsetup);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.IPsetup.ResumeLayout(false);
            this.IPsetup.PerformLayout();
            this.IPsetup2.ResumeLayout(false);
            this.IPsetup2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Send;
        private System.Windows.Forms.Button tb2OFF;
        private System.Windows.Forms.Button tb2ON;
        private System.Windows.Forms.Button tb1OFF;
        private System.Windows.Forms.Button tb1ON;
        private System.Windows.Forms.Button tb8OFF;
        private System.Windows.Forms.Button tb8ON;
        private System.Windows.Forms.Button tb7OFF;
        private System.Windows.Forms.Button tb7ON;
        private System.Windows.Forms.Button tb6OFF;
        private System.Windows.Forms.Button tb6ON;
        private System.Windows.Forms.Button tb5OFF;
        private System.Windows.Forms.Button tb5ON;
        private System.Windows.Forms.Button tb4OFF;
        private System.Windows.Forms.Button tb4ON;
        private System.Windows.Forms.Button tb3OFF;
        private System.Windows.Forms.Button tb3ON;
        private System.Windows.Forms.TextBox IP1;
        private System.Windows.Forms.TextBox IP2;
        private System.Windows.Forms.TextBox IP3;
        private System.Windows.Forms.TextBox IP4;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.GroupBox IPsetup;
        private System.Windows.Forms.GroupBox IPsetup2;
        private System.Windows.Forms.Button Save2;
        private System.Windows.Forms.TextBox IP42;
        private System.Windows.Forms.TextBox IP32;
        private System.Windows.Forms.TextBox IP22;
        private System.Windows.Forms.TextBox IP12;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button tb8OFF2;
        private System.Windows.Forms.Button tb8ON2;
        private System.Windows.Forms.Button tb7OFF2;
        private System.Windows.Forms.Button tb7ON2;
        private System.Windows.Forms.Button tb6OFF2;
        private System.Windows.Forms.Button tb6ON2;
        private System.Windows.Forms.Button tb5OFF2;
        private System.Windows.Forms.Button tb5ON2;
        private System.Windows.Forms.Button tb4OFF2;
        private System.Windows.Forms.Button tb4ON2;
        private System.Windows.Forms.Button tb3OFF2;
        private System.Windows.Forms.Button tb3ON2;
        private System.Windows.Forms.Button tb2OFF2;
        private System.Windows.Forms.Button tb2ON2;
        private System.Windows.Forms.Button tb1OFF2;
        private System.Windows.Forms.Button tb1ON2;
        private System.Windows.Forms.Button Send2;
        private System.Windows.Forms.Button Disconnect1;
        private System.Windows.Forms.Label Text2;
        private System.Windows.Forms.Label Text1;
        private System.Windows.Forms.Button Disconnect2;
        private System.Windows.Forms.ListBox lstRegvalues;
    }
}

